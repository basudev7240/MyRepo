package com.fsg.fisglobal.authman.model;

public enum Gender {
    MALE, FEMALE
}
