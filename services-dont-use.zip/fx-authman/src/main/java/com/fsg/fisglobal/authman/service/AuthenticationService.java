package com.fsg.fisglobal.authman.service;

 
import org.springframework.http.ResponseEntity;

import com.fsg.fisglobal.authman.payload.ForgotPasswordRequest;
import com.fsg.fisglobal.authman.payload.LoginRequest;
import com.fsg.fisglobal.authman.payload.RegisterRequest;
import com.fsg.fisglobal.authman.payload.RegisterResponse;
import com.fsg.fisglobal.authman.payload.RegisterVerifyRequest;
import com.fsg.fisglobal.authman.payload.ResetPasswordRequest;




public interface AuthenticationService {
      ResponseEntity<RegisterResponse> registerUser(RegisterRequest registerRequest);
      ResponseEntity<?> verifyUserRegistration(RegisterVerifyRequest registerVerifyRequest);
      ResponseEntity<?> loginUser(LoginRequest loginRequest);
      ResponseEntity<?> resendOtp(ForgotPasswordRequest forgotPasswordRequest);
      ResponseEntity<?> verifyOtp(RegisterVerifyRequest registerVerifyRequest);
      ResponseEntity<?> resetPassword(ResetPasswordRequest resetPasswordRequest);
      ResponseEntity<?> myProfile(ForgotPasswordRequest forgotPasswordRequest);
      ResponseEntity<?> validateToken(String accessToken);
     


}
