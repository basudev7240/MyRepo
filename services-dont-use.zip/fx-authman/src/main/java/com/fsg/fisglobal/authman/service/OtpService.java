package com.fsg.fisglobal.authman.service;
 
import java.util.Random;

import org.springframework.cache.annotation.CachePut;
import org.springframework.stereotype.Service;

import com.fsg.fisglobal.authman.constants.ApplicationConstants;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class OtpService {
	
    String otpChar = ApplicationConstants.OTP_CHARACTERS;
    Integer otpLength = ApplicationConstants.OTP_LENGTH;

    public String generateOtp() {
        StringBuilder otp = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < otpLength; i++) {
            otp.append(otpChar.charAt(random.nextInt(otpChar.length())));
        }
        System.out.println("Generated OTP: {}" +otp);
        return otp.toString();
    }

    @CachePut(value = "user", key = "#email")
    public String getOtpForEmail(String email) {
        return generateOtp();
    }
}
