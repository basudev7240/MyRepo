package com.fsg.fisglobal.authman.config;

import org.springframework.boot.actuate.autoconfigure.tracing.BraveAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import(BraveAutoConfiguration.class)
public class TracingConfig {

    
}