package com.fsg.fisglobal.authman.model;

public enum Role {
    USER,
    ADMIN
}
