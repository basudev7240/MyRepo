package com.fsg.fisglobal.authman.service;

import org.springframework.stereotype.Component;

@Component
public interface UserDetailsService {

}
