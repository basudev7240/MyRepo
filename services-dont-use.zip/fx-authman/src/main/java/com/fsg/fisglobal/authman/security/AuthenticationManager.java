package com.fsg.fisglobal.authman.security;

import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class AuthenticationManager {
	
	public void authenticate(UsernamePasswordAuthentication authentication) {
		log.info("call profile validate credentials");
	}

}
