package com.fsg.fisglobal.authman.service;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.fsg.fisglobal.authman.controller.AuthenticationController;
import com.fsg.fisglobal.authman.exception.ResourceNotFoundException;
import com.fsg.fisglobal.authman.model.User;
import com.fsg.fisglobal.authman.payload.GeneralAPIResponse;
import com.fsg.fisglobal.authman.payload.RefreshTokenResponse;
import com.fsg.fisglobal.authman.payload.RegisterVerifyResponse;
import com.fsg.fisglobal.authman.repository.UserRepository;
import com.fsg.fisglobal.authman.util.JwtUtil;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class JwtService {
    private final JwtUtil jwtUtil;
  //  private final UserDetailsService userDetailsService;
    private final UserRepository userRepository;

    public RegisterVerifyResponse generateJwtToken(User user)
    {
         String myAccessToken = jwtUtil.generateAccessToken(user);
         String myRefreshToken = jwtUtil.generateRefreshToken(user);
         return RegisterVerifyResponse.builder()
                 .accessToken(myAccessToken)
                 .refreshToken(myRefreshToken)
                 .firstName(user.getName().getFirstName())
                 .lastName(user.getName().getLastName())
                 .email(user.getEmail())
                 .role(user.getRole())
                 .isVerified(user.getIsVerified())
                 .build();
    }

    public ResponseEntity<?> generateAccessTokenFromRefreshToken(String refreshToken) {
       if(refreshToken != null)
       {
           try
           {
               String username = jwtUtil.extractUsername(refreshToken);
               if(username.startsWith("#refresh"))
               {
                   String finalUserName = username.substring(8);
                   UserDetails userDetails =null; //userDetailsService.loadUserByUsername(finalUserName);
                   User user = userRepository.findByEmail(finalUserName).orElseThrow(
                           ()-> new ResourceNotFoundException("User not found with email "+finalUserName)
                   );
                   if(jwtUtil.isRefreshTokenValid(refreshToken, userDetails))
                   {
                       String accessToken  = jwtUtil.generateAccessToken(userDetails);
                       return new ResponseEntity<>(RefreshTokenResponse.builder()
                               .accessToken(accessToken)
                               .firstName(user.getName().getFirstName())
                               .lastName(user.getName().getLastName())
                               .email(user.getEmail())
                               .role(user.getRole())
                               .build() , HttpStatus.OK);
                   }
                   else
                   {
                       return new ResponseEntity<>(GeneralAPIResponse.builder().message("Refresh token is expired").build() , HttpStatus.BAD_REQUEST);
                   }
               }
               else
               {
                   return new ResponseEntity<>(GeneralAPIResponse.builder().message("Invalid refresh token").build() , HttpStatus.BAD_REQUEST);
               }
           }
           catch(IllegalArgumentException | MalformedJwtException e)
              {
                return new ResponseEntity<>(GeneralAPIResponse.builder().message("Invalid refresh token").build() , HttpStatus.BAD_REQUEST);
              }
           catch(ResourceNotFoundException e)
           {
               return new ResponseEntity<>(GeneralAPIResponse.builder().message("User not found").build() , HttpStatus.NOT_FOUND);
           }
           catch(ExpiredJwtException e)
           {
                return new ResponseEntity<>(GeneralAPIResponse.builder().message("Refresh token is expired").build() , HttpStatus.BAD_REQUEST);
           }

       }
       else
       {
           return new ResponseEntity<>(GeneralAPIResponse.builder().message("Refresh token is null").build() , HttpStatus.BAD_REQUEST);
       }

    }
    
    
    public boolean validateJwtToken(String accessToken)
    {
    	 boolean istokenExpired=true;
    	try {
            String username = jwtUtil.extractUsername(accessToken);
             istokenExpired=jwtUtil.validateToken(accessToken, username);
            
         
            
        }
        catch(IllegalStateException e) {log.error("Error extracting username from token");}
        catch(ExpiredJwtException e) {log.error("Token has expired");}
        catch(MalformedJwtException e) {log.error("Token is malformed");}
        catch(Exception e) {log.error("An error occurred while extracting username from token");}
    	
    	return istokenExpired;
         
    }
    

}
