package com.fsg.fisglobal.authman.exception;

public class BadCredentialsException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String message;

	public BadCredentialsException(String message) {
		super();
		this.message = message;
	}
	
	

}
