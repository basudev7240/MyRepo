package com.fsg.fisglobal.authman;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FxAuthmanApplicationTests {

	@Test
	void contextLoads() {
	}

}
