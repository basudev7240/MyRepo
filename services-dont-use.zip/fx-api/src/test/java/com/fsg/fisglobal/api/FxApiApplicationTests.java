package com.fsg.fisglobal.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FxApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
