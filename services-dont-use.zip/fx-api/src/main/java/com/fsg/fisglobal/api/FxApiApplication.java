package com.fsg.fisglobal.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FxApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FxApiApplication.class, args);
	}

}
