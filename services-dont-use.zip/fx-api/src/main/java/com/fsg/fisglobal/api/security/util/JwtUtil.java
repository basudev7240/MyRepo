package com.fsg.fisglobal.api.security.util;

import java.util.Date;
import java.util.function.Function;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import com.fsg.fisglobal.api.security.AccessToken;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;

@Component
public class JwtUtil {
	
	
	private String SECRET_KEY = "a457a368c614c1369066ae25bcb0c5a8445276f80491e42feb9d1c8196d840c0";

     
	//retrieve username from jwt token
    public String getUsernameFromToken(String token) {
        return getClaimFromToken(token, Claims::getSubject);
    }

    //retrieve expiration date from jwt token
    public Date getExpirationDateFromToken(String token) {
        return getClaimFromToken(token, Claims::getExpiration);
    }

    public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = getAllClaimsFromToken(token);
        return claimsResolver.apply(claims);
    }

    //for retrieveing any information from token we will need the secret key
    private Claims getAllClaimsFromToken(String token) {
        return Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token).getBody();
    }

    //check if the token has expired
    private Boolean isTokenExpired(String token) {
        final Date expiration = getExpirationDateFromToken(token);
        return expiration.before(new Date());
    }

 
    

    //validate token
    public AccessToken validateToken(String token) {
    	
    	 
    	AccessToken accessToken=null;
    	 String username=null;
    	try {
    		username  = getUsernameFromToken(token);
        
        
    	}catch(Exception e) {
    		System.out.println("token validation exception"+e);
    	}
        
    	if(! isTokenExpired(token)) {
    		accessToken=new AccessToken();
    		Claims claims= getAllClaimsFromToken( token);
    		accessToken.setUsername(username);
    		//accessToken.setRole(claims);
    	}
        
        return  accessToken ;
    }

     
}
